#!/usr/bin/env python3
"""스펙 마크다운을 Confluence HTML 본문으로 변환.
사용법: md_to_confluence.py <spec.md> [--diagram-mode attach|macro] [--media-json map.json]
- attach: media-json의 {파일명: {"mediaId", "collection"}}로 이미지를 media figure로 넣음
- macro: 이미지 경로의 .mmd와 -macro.png를 찾아 Mermaid 블록으로 넣음
- 표의 첫 열이 #이면 열 폭을 고정하고 첫 열을 40으로 좁힘
- 화면, 진입점, 상세 내용 3열 표(New Product)는 140, 200, 나머지로 고정
- [글자](#제목)은 같은 페이지 제목으로 가는 링크로 바꿈
- 표 셀 안의 '- ' 줄은 불릿, '  - ' 는 한 단계 아래 불릿, '1. ' 은 번호 목록으로 바꿈
- 변환 직전 금지 기호를 치환
- 변환 전에 lint_spec.py 검사를 돌리고, 위반이 있으면 본문을 만들지 않고 종료 코드 1 (게시 차단)"""
import argparse
import html
import json
import os
import re
import subprocess
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from mermaid_macro import build as build_macro, quantize_png  # noqa: E402

INLINE_CODE = re.compile(r"`[^`]*`")
REPLACE = {"·": "/", "—": ", ", "–": ", "}
CIRCLED = {chr(0x2460 + i): f"{i + 1}." for i in range(20)}
TABLE_WIDTH = 760
NUM_COL = 40


def clean(text):
    for k, v in REPLACE.items():
        text = text.replace(k, v)
    for k, v in CIRCLED.items():
        text = text.replace(k, v)
    return text


def inline(text):
    text = clean(text)
    parts = re.split(r"(<br\s*/?>)", text)
    out = []
    for p in parts:
        if re.fullmatch(r"<br\s*/?>", p):
            out.append("<br>")
            continue
        p = html.escape(p, quote=False)
        p = re.sub(r"`([^`]+)`", r"<code>\1</code>", p)
        p = re.sub(r"\*\*([^*]+)\*\*", r"<strong>\1</strong>", p)
        p = re.sub(r"\[([^\]]+)\]\((https?://(?:[^()\s]|\([^()\s]*\))+)\)", r'<a href="\2">\1</a>', p)
        # 맨 URL(상위 문서, Jira 에픽 링크)은 누를 수 있는 스마트 링크로. 이미 <a> 안에 있는 URL은 건드리지 않음
        p = re.sub(r'(?<!href=")(?<![">])(https?://[^\s<>"\')]+)', r'<a href="\1" data-card-appearance="inline"></a>', p)
        # 문서 안 링크 [신청 취소](#신청-취소) → 제목 앵커. Confluence 앵커는 제목의 공백을 하이픈으로 바꾼 값
        p = re.sub(r"\[([^\]]+)\]\(#([^)]+)\)", lambda m: f'<a href="#{m.group(2).strip().replace(" ", "-")}">{m.group(1)}</a>', p)
        out.append(p)
    return "".join(out)


def split_cells(row):
    """| a | `x|y` | c \\| d | → 인라인 코드 안의 |와 이스케이프된 \\|는 구분자로 보지 않음"""
    protected = []

    def keep(m):
        protected.append(m.group(0))
        return f"\x00{len(protected) - 1}\x00"

    tmp = INLINE_CODE.sub(keep, row).replace("\\|", "\x01")
    cells = tmp.strip().strip("|").split("|")
    out = []
    for c in cells:
        c = c.replace("\x01", "|")
        c = re.sub(r"\x00(\d+)\x00", lambda m: protected[int(m.group(1))], c)
        out.append(c)
    return out


def cell_html(text):
    """표 셀 안의 줄(<br>로 나눔)을 블록으로 바꿈.
    '- ' 로 시작하면 불릿, '  - ' 처럼 들여쓰면 한 단계 아래 불릿, '1. ' 은 번호 목록, 나머지는 문단"""
    lines = [x for x in re.split(r"<br\s*/?>", text)]
    if len(lines) == 1 and not re.match(r"^\s*(-|\d+\.)\s", lines[0]):
        return f"<p>{inline(lines[0].strip())}</p>"
    out, stack = [], []  # stack: 열린 목록 태그와 들여쓰기

    def close_to(level):
        while stack and stack[-1][1] >= level:
            tag, _ = stack.pop()
            out.append(f"</li></{tag}>")

    for raw in lines:
        if not raw.strip():
            continue
        m = re.match(r"^(\s*)(-|\d+\.)\s+(.*)$", raw)
        if not m:
            close_to(0)
            out.append(f"<p>{inline(raw.strip())}</p>")
            continue
        level = len(m.group(1).replace("\t", "  ")) // 2
        tag = "ol" if m.group(2)[0].isdigit() else "ul"
        close_to(level + 1)  # 더 깊은 목록은 닫음
        if stack and stack[-1][1] == level and stack[-1][0] == tag:
            out.append("</li>")  # 같은 목록의 다음 항목
        else:
            if stack and stack[-1][1] == level:
                close_to(level)  # 같은 깊이인데 목록 종류가 바뀜
            out.append(f"<{tag}>")
            stack.append((tag, level))
        out.append(f"<li><p>{inline(m.group(3).strip())}</p>")
    close_to(0)
    return "".join(out)


class Converter:
    def __init__(self, base_dir, mode, media):
        self.base_dir = base_dir
        self.mode = mode
        self.media = media
        self.notes = []

    def image(self, alt, path):
        name = os.path.basename(path)
        if self.mode == "attach":
            m = self.media.get(name) or self.media.get(path)
            # storage 형식으로 올릴 때는 figure media-single이 저장되지 않고 그림이 사라짐.
            # media.json에 filename(첨부 파일명)이 있으면 storage용 ac:image로 내보냄
            if m and m.get("filename"):
                return (f'<p><ac:image ac:align="center" ac:layout="center" ac:custom-width="true" '
                        f'ac:width="760" ac:alt="{html.escape(alt or name)}">'
                        f'<ri:attachment ri:filename="{html.escape(m["filename"])}" /></ac:image></p>')
            if m and m.get("mediaId"):
                return (f'<figure data-type="media-single" data-layout="center" data-width="80" '
                        f'data-width-type="percentage"><div data-type="media" data-media-type="file" '
                        f'data-id="{html.escape(m["mediaId"])}" data-collection="{html.escape(m["collection"])}" '
                        f'data-alt="{html.escape(name)}"></div></figure>')
            self.notes.append(f"첨부 정보 없음: {name} (media.json에 미디어 ID 없음). 블록 또는 안내 상자로 대체. 첨부는 올라가 있으면 편집 화면에서 끌어다 놓아도 됨")
        stem = os.path.splitext(os.path.join(self.base_dir, path))[0]
        mmd, png = stem + ".mmd", stem + "-macro.png"
        if os.path.exists(mmd) and not os.path.exists(png):
            script = os.path.join(os.path.dirname(os.path.abspath(__file__)), "render_diagram.sh")
            try:
                subprocess.run(["bash", script, mmd, png, "macro"], capture_output=True, timeout=120)
            except subprocess.TimeoutExpired:
                self.notes.append(f"렌더 시간 초과: {mmd}")
        if os.path.exists(mmd) and os.path.exists(png):
            data = quantize_png(open(png, "rb").read())
            m_w = int.from_bytes(data[16:20], "big") if len(data) > 24 else 0
            m_h = int.from_bytes(data[20:24], "big") if len(data) > 24 else 0
            b64_len = len(data) * 4 // 3
            kind = open(mmd, encoding="utf-8").readline().strip().split()[0] if os.path.exists(mmd) else "flowchart"
            label = {"flowchart": "흐름도", "graph": "흐름도", "stateDiagram-v2": "상태도", "stateDiagram": "상태도", "sequenceDiagram": "순서도"}.get(kind, "다이어그램")
            # 블록은 폭 300px로 표시된다. 블록용 그림이 납작하거나(높이 120 미만, 가로세로비 2.5 초과) 크면(8KB 초과) 읽히지 않는다
            if b64_len > 8 * 1024 or (m_h and m_h < 120) or (m_w and m_h and m_w / m_h > 2.5):
                self.notes.append(f"블록 대신 안내 상자: {name} (base64 {b64_len // 1024}KB, 블록 {m_w}x{m_h}). 편집 → /mermaid → {os.path.relpath(mmd, self.base_dir)} 붙여넣기")
                return (f'<div data-type="panel-info"><p>{label} 자리. 편집 화면에서 /mermaid 를 넣고 '
                        f'{html.escape(os.path.relpath(mmd, self.base_dir))} 의 코드를 붙여넣어 주세요. 그림 파일 {html.escape(path)}</p></div>')
            return build_macro(open(mmd, encoding="utf-8").read().strip(), data)
        self.notes.append(f"그림 파일 없음: {mmd} 또는 {png}")
        return f'<div data-type="panel-warning"><p>다이어그램 파일 없음: {html.escape(path)}. 스펙 폴더의 diagrams에서 그림을 만들어 끌어다 놓아 주세요</p></div>'

    def table(self, rows):
        header, body = rows[0], rows[2:]
        ncol = len(header)
        numbered = header[0].strip() == "#"
        widths = None
        names = [h.strip() for h in header]
        screen_table = names == ["화면", "진입점", "상세 내용"]
        if screen_table:
            widths = [140, 200, TABLE_WIDTH - 340]
        if numbered:
            names = [h.strip() for h in header]
            if names == ["#", "진입점", "화면", "기능", "요구사항"]:
                widths = [NUM_COL, 140, 140, 120, TABLE_WIDTH - NUM_COL - 400]
            else:
                rest = (TABLE_WIDTH - NUM_COL) // max(ncol - 1, 1)
                widths = [NUM_COL] + [rest] * (ncol - 1)
        attrs = ' data-display-mode="fixed"' if (numbered or screen_table) else ""
        out = [f"<table{attrs}><thead><tr>"]
        for i, c in enumerate(header):
            w = f' data-colwidth="{widths[i]}"' if widths else ""
            out.append(f"<th{w}><p>{inline(c.strip())}</p></th>")
        out.append("</tr></thead><tbody>")
        for r in body:
            r = (r + [""] * ncol)[:ncol]
            out.append("<tr>")
            for i, c in enumerate(r):
                w = f' data-colwidth="{widths[i]}"' if widths else ""
                out.append(f"<td{w}>{cell_html(c.strip())}</td>")
            out.append("</tr>")
        out.append("</tbody></table>")
        return "".join(out)

    def convert(self, text):
        text = re.sub(r"<!--.*?-->", "", text, flags=re.S)
        lines = text.split("\n")
        out, i = [], 0
        while i < len(lines):
            line = lines[i]
            s = line.strip()
            if not s:
                i += 1
                continue
            if s.startswith("```"):
                lang = s[3:].strip()
                i += 1
                code = []
                while i < len(lines) and not lines[i].strip().startswith("```"):
                    code.append(lines[i])
                    i += 1
                i += 1
                cls = f' class="language-{html.escape(lang)}"' if lang else ""
                out.append(f"<pre><code{cls}>{html.escape(chr(10).join(code))}</code></pre>")
                continue
            m = re.match(r"^(#{1,6})\s+(.*)", s)
            if m:
                out.append(f"<h{len(m.group(1))}>{inline(m.group(2))}</h{len(m.group(1))}>")
                i += 1
                continue
            m = re.match(r"^!\[([^\]]*)\]\(([^)]+)\)", s)
            if m:
                out.append(self.image(m.group(1), m.group(2)))
                i += 1
                continue
            if s.startswith("|"):
                rows = []
                while i < len(lines) and lines[i].strip().startswith("|"):
                    rows.append(split_cells(lines[i].strip()))
                    i += 1
                if len(rows) >= 2:
                    out.append(self.table(rows))
                continue
            if re.match(r"^[-*]\s", s) or re.match(r"^\d+\.\s", s):
                # 들여쓰기로 묶은 목록. 들여쓰기 폭(2칸, 4칸 모두)을 깊이 순서로 바꿔 표 셀과 같은 방식으로 변환
                items = []
                while i < len(lines) and (re.match(r"^\s*[-*]\s", lines[i]) or re.match(r"^\s*\d+\.\s", lines[i])):
                    m2 = re.match(r"^(\s*)([-*]|\d+\.)\s+(.*)$", lines[i])
                    items.append((len(m2.group(1).replace("\t", "    ")), "-" if m2.group(2) in "-*" else m2.group(2), m2.group(3)))
                    i += 1
                widths = sorted({w for w, _, _ in items})
                joined = "<br>".join("  " * widths.index(w) + f"{mark} {body}" for w, mark, body in items)
                out.append(cell_html(joined))
                continue
            para = [s]
            i += 1
            while i < len(lines) and lines[i].strip() and not re.match(r"^(#|\||[-*]\s|\d+\.\s|!\[)", lines[i].strip()):
                para.append(lines[i].strip())
                i += 1
            out.append(f"<p>{inline(' '.join(para))}</p>")
        return "".join(out)


def main():
    ap = argparse.ArgumentParser(description="스펙 마크다운을 Confluence HTML로 변환")
    ap.add_argument("spec")
    ap.add_argument("--diagram-mode", choices=["attach", "macro"], default="attach")
    ap.add_argument("--media-json", help='{"파일명": {"mediaId": "...", "collection": "..."}}')
    ap.add_argument("--out", help="본문을 이 파일에도 저장")
    a = ap.parse_args()
    # 게시 전 lint 통과 필수. 위반이 있으면 본문을 만들지 않는다 (Confluence에 올라가는 것을 코드로 막음)
    import lint_spec  # noqa: E402
    issues = lint_spec.check(a.spec) + lint_spec.check_counts(a.spec) + lint_spec.check_structure(a.spec) + lint_spec.check_shape(a.spec)
    if issues:
        for n, kind, what in issues:
            print(f"{a.spec}:{n}: {kind}: {what}", file=sys.stderr)
        print(f"lint 위반 {len(issues)}건. 고친 뒤 다시 변환하세요. 본문을 만들지 않았습니다 (게시 중단)", file=sys.stderr)
        return 1
    print("lint 통과", file=sys.stderr)
    media = json.load(open(a.media_json, encoding="utf-8")) if a.media_json else {}
    conv = Converter(os.path.dirname(os.path.abspath(a.spec)), a.diagram_mode, media)
    body = conv.convert(open(a.spec, encoding="utf-8").read())
    if a.out:
        with open(a.out, "w", encoding="utf-8") as f:
            f.write(body)
    sys.stdout.write(body)
    print(f"\n본문 크기: {len(body.encode('utf-8')) // 1024}KB", file=sys.stderr)
    for n in conv.notes:
        print(n, file=sys.stderr)
    return 0


if __name__ == "__main__":
    sys.exit(main())
